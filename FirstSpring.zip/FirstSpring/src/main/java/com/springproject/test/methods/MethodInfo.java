package com.springproject.test.methods;

public class MethodInfo {
private String city;

public MethodInfo(String city) {
	
	this.city = city;
}

@Override
public String toString() {
	return "City [city=" + city + "]";
}

}
